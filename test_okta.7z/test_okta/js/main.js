/**

/**
 * Main AngularJS Web Application
 */
var app = angular.module('tutorialWebApp', [
  'ngRoute'
]);

/**
 * Configure the Routes
 */
app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
    .when("/about", {templateUrl: "partials/about.html", controller: "PageCtrl"})
    // Blog
    .when("/services", {templateUrl: "partials/blog.html", controller: "BlogCtrl"})
    .when("/callback", {templateUrl: "partials/blog_item.html", controller: "CallbackCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
	  $locationProvider.html5Mode(true);
    $locationProvider.hashPrefix('');
}]);

/**
 * Controls the Blog
 */
app.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});

app.controller('CallbackCtrl', function (/* $scope, $location, $http */) {
  console.log("CallbackCtrl Controller reporting for duty.");
});

/**
 * Controls all other Pages
 */
app.controller('PageCtrl', function (/* $scope, $location, $http */) {
  console.log("Page Controller reporting for duty.");
  var config = {
    // Required config
    issuer: 'https://dev-39679687.okta.com/oauth2/default',
  
    // Required for login flow using getWithRedirect()
    clientId: '0oa2kjcxpfcM3LGtH5d7',
    redirectUri: 'http://localhost/test_okta/callback',
    authParams: {
      issuer: 'default',
      responseType: ['id_token','token']
    },
    devMode: true
  };
  
  var authClient = new OktaAuth(config);
  
  authClient.start(); // start the service
  console.log('fff'+authClient.getOriginalUri());
  //authClient.stop();

  // Activates the Carousel
  $('.carousel').carousel({
    interval: 5000
  });

  // Activates Tooltips for Social Links
  $('.tooltip-social').tooltip({
    selector: "a[data-toggle=tooltip]"
  })
});